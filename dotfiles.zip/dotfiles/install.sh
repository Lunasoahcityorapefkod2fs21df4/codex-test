#!/usr/bin/env bash
# ============================================
# Hyprland Dotfiles Installer
# Arch Linux — VMware compatible
# ============================================

set -e

DOTFILES_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG="$HOME/.config"
BACKUP="$HOME/.config-backup-$(date +%Y%m%d-%H%M%S)"

RED='\033[0;31m'; GRN='\033[0;32m'; YLW='\033[1;33m'
BLU='\033[0;34m'; CYN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

info() { echo -e "${BLU}[INFO]${NC}  $1"; }
ok()   { echo -e "${GRN}[ OK ]${NC}  $1"; }
warn() { echo -e "${YLW}[WARN]${NC}  $1"; }
step() { echo -e "\n${BOLD}${CYN}==> $1${NC}"; }

# ============================================
# STEP 1 — Install yay
# ============================================
install_yay() {
    if command -v yay &>/dev/null; then
        ok "yay already installed"; return
    fi
    step "Installing yay"
    sudo pacman -S --needed --noconfirm git base-devel
    git clone https://aur.archlinux.org/yay.git /tmp/yay-install
    cd /tmp/yay-install && makepkg -si --noconfirm
    cd "$DOTFILES_DIR"
    ok "yay installed"
}

# ============================================
# STEP 2 — Install packages
# ============================================
install_packages() {
    step "Installing pacman packages"
    sudo pacman -S --needed --noconfirm \
        waybar hyprpaper dunst kitty wofi \
        pipewire pipewire-pulse wireplumber pavucontrol \
        grim slurp wl-clipboard \
        zsh starship fzf fd \
        eza bat btop zoxide \
        playerctl brightnessctl \
        ttf-jetbrains-mono-nerd papirus-icon-theme noto-fonts \
        polkit-kde-agent thunar \
        xdg-user-dirs git curl wget unzip
    ok "pacman packages done"

    step "Installing AUR packages"
    yay -S --needed --noconfirm \
        cliphist \
        bibata-cursor-theme-bin \
        catppuccin-gtk-theme-mocha \
        wlogout
    ok "AUR packages done"
}

# ============================================
# STEP 3 — Install Oh My Zsh
# ============================================
install_omz() {
    step "Installing Oh My Zsh"
    if [ -d "$HOME/.oh-my-zsh" ]; then
        ok "Oh My Zsh already installed"
    else
        RUNZSH=no CHSH=no sh -c \
            "$(curl -fsSL https://raw.githubusercontent.com/ohmyzsh/ohmyzsh/master/tools/install.sh)"
        ok "Oh My Zsh installed"
    fi

    ZSH_CUSTOM="${ZSH_CUSTOM:-$HOME/.oh-my-zsh/custom}"

    if [ ! -d "$ZSH_CUSTOM/plugins/zsh-autosuggestions" ]; then
        git clone --depth=1 https://github.com/zsh-users/zsh-autosuggestions \
            "$ZSH_CUSTOM/plugins/zsh-autosuggestions"
        ok "zsh-autosuggestions"
    else
        ok "zsh-autosuggestions already present"
    fi

    if [ ! -d "$ZSH_CUSTOM/plugins/zsh-syntax-highlighting" ]; then
        git clone --depth=1 https://github.com/zsh-users/zsh-syntax-highlighting \
            "$ZSH_CUSTOM/plugins/zsh-syntax-highlighting"
        ok "zsh-syntax-highlighting"
    else
        ok "zsh-syntax-highlighting already present"
    fi

    if [ ! -d "$ZSH_CUSTOM/plugins/zsh-completions" ]; then
        git clone --depth=1 https://github.com/zsh-users/zsh-completions \
            "$ZSH_CUSTOM/plugins/zsh-completions"
        ok "zsh-completions"
    else
        ok "zsh-completions already present"
    fi
}

# ============================================
# STEP 4 — Backup existing configs
# ============================================
backup_configs() {
    step "Backing up existing configs to $BACKUP"
    mkdir -p "$BACKUP"
    for dir in hypr waybar wofi kitty dunst gtk-3.0 gtk-4.0; do
        [ -d "$CONFIG/$dir" ] && cp -r "$CONFIG/$dir" "$BACKUP/" && ok "Backed up $dir"
    done
    [ -f "$HOME/.zshrc" ] && cp "$HOME/.zshrc" "$BACKUP/.zshrc" && ok "Backed up .zshrc"
}

# ============================================
# STEP 5 — Install dotfiles
# ============================================
install_dotfiles() {
    step "Installing dotfiles"
    mkdir -p "$CONFIG"

    for dir in hypr waybar wofi kitty dunst gtk-3.0 gtk-4.0; do
        rm -rf "$CONFIG/$dir"
        cp -r "$DOTFILES_DIR/$dir" "$CONFIG/$dir"
        ok "$dir"
    done

    cp "$DOTFILES_DIR/zsh/.zshrc" "$HOME/.zshrc" && ok ".zshrc"
    cp "$DOTFILES_DIR/zsh/starship.toml" "$CONFIG/starship.toml" && ok "starship.toml"
    ok "All dotfiles installed"
}

# ============================================
# STEP 6 — Set zsh as default shell
# ============================================
set_shell() {
    step "Setting zsh as default shell"
    if [ "$SHELL" = "$(which zsh)" ]; then
        ok "zsh is already the default shell"
    else
        chsh -s "$(which zsh)"
        ok "Default shell set to zsh"
    fi
}

# ============================================
# STEP 7 — Create directories & enable services
# ============================================
finalize() {
    step "Creating directories"
    mkdir -p ~/Pictures/Screenshots ~/.local/bin ~/.local/share/zsh ~/.cache/zsh
    xdg-user-dirs-update 2>/dev/null || true
    ok "Directories ready"

    step "Enabling audio services"
    systemctl --user enable --now pipewire.service       2>/dev/null && ok "pipewire"       || warn "pipewire already enabled or not needed"
    systemctl --user enable --now pipewire-pulse.service 2>/dev/null && ok "pipewire-pulse" || warn "pipewire-pulse already enabled or not needed"
    systemctl --user enable --now wireplumber.service    2>/dev/null && ok "wireplumber"    || warn "wireplumber already enabled or not needed"
}

# ============================================
# MAIN
# ============================================
echo -e "\n${BOLD}${CYN}"
echo "  ██╗  ██╗██╗   ██╗██████╗ ██████╗ "
echo "  ██║  ██║╚██╗ ██╔╝██╔══██╗██╔══██╗"
echo "  ███████║ ╚████╔╝ ██████╔╝██████╔╝"
echo "  ██╔══██║  ╚██╔╝  ██╔═══╝ ██╔══██╗"
echo "  ██║  ██║   ██║   ██║     ██║  ██║"
echo "  ╚═╝  ╚═╝   ╚═╝   ╚═╝     ╚═╝  ╚═╝"
echo -e "${NC}${BOLD}  Dotfiles Installer — Arch Linux / VMware${NC}\n"

echo -n "Continue? [y/N] "
read -r response
[[ ! "$response" =~ ^[Yy]$ ]] && { info "Aborted."; exit 0; }

install_yay
install_packages
install_omz
backup_configs
install_dotfiles
set_shell
finalize

echo ""
echo -e "${BOLD}${GRN}✓ All done! Log out of SDDM and log back in.${NC}"
echo ""
echo -e "${CYN}Keybindings:${NC}"
echo "  Super + Return  → Terminal (kitty)"
echo "  Super + R       → App launcher (wofi)"
echo "  Super + Q       → Close window"
echo "  Super + H/J/K/L → Move focus"
echo "  Super + 1-5     → Switch workspace"
echo "  Print           → Screenshot to clipboard"
echo ""
