#!/usr/bin/env bash
# ============================================
# Hyprland Dotfiles Install Script
# ============================================

set -e

DOTFILES_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_DIR="$HOME/.config"
BACKUP_DIR="$HOME/.config-backup-$(date +%Y%m%d-%H%M%S)"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

info()    { echo -e "${BLUE}[INFO]${NC} $1"; }
success() { echo -e "${GREEN}[OK]${NC} $1"; }
warn()    { echo -e "${YELLOW}[WARN]${NC} $1"; }
error()   { echo -e "${RED}[ERROR]${NC} $1"; }

print_header() {
    echo -e "\n${BOLD}${CYAN}"
    echo "  ██╗  ██╗██╗   ██╗██████╗ ██████╗ "
    echo "  ██║  ██║╚██╗ ██╔╝██╔══██╗██╔══██╗"
    echo "  ███████║ ╚████╔╝ ██████╔╝██████╔╝"
    echo "  ██╔══██║  ╚██╔╝  ██╔═══╝ ██╔══██╗"
    echo "  ██║  ██║   ██║   ██║     ██║  ██║"
    echo "  ╚═╝  ╚═╝   ╚═╝   ╚═╝     ╚═╝  ╚═╝"
    echo -e "  ${NC}${BOLD}Dotfiles Installer — Catppuccin Mocha${NC}\n"
}

backup_existing() {
    if [ -d "$CONFIG_DIR" ]; then
        info "Backing up existing configs to $BACKUP_DIR"
        mkdir -p "$BACKUP_DIR"
        for dir in hypr waybar wofi kitty dunst gtk-3.0 gtk-4.0; do
            if [ -d "$CONFIG_DIR/$dir" ]; then
                cp -r "$CONFIG_DIR/$dir" "$BACKUP_DIR/" 2>/dev/null || true
                success "Backed up $dir"
            fi
        done
    fi
}

install_config() {
    local src="$1"
    local dest="$2"
    mkdir -p "$(dirname "$dest")"
    cp -r "$src" "$dest"
    success "Installed $(basename "$src") → $dest"
}

link_dotfiles() {
    info "Installing dotfiles..."

    # Hyprland
    install_config "$DOTFILES_DIR/hypr"       "$CONFIG_DIR/hypr"

    # Waybar
    install_config "$DOTFILES_DIR/waybar"     "$CONFIG_DIR/waybar"

    # Wofi
    install_config "$DOTFILES_DIR/wofi"       "$CONFIG_DIR/wofi"

    # Kitty
    install_config "$DOTFILES_DIR/kitty"      "$CONFIG_DIR/kitty"

    # Dunst
    install_config "$DOTFILES_DIR/dunst"      "$CONFIG_DIR/dunst"

    # GTK
    install_config "$DOTFILES_DIR/gtk-3.0"    "$CONFIG_DIR/gtk-3.0"
    install_config "$DOTFILES_DIR/gtk-4.0"    "$CONFIG_DIR/gtk-4.0"

    # Zsh
    cp "$DOTFILES_DIR/zsh/.zshrc" "$HOME/.zshrc"
    success "Installed .zshrc → $HOME/.zshrc"

    # Starship
    mkdir -p "$CONFIG_DIR"
    cp "$DOTFILES_DIR/zsh/starship.toml" "$CONFIG_DIR/starship.toml"
    success "Installed starship.toml"

    # Scripts
    mkdir -p "$HOME/.local/bin"
    cp -r "$DOTFILES_DIR/scripts/"* "$HOME/.local/bin/" 2>/dev/null || true
    chmod +x "$HOME/.local/bin/"* 2>/dev/null || true
}

check_deps() {
    info "Checking dependencies..."
    local missing=()
    local deps=(hyprland waybar wofi kitty dunst starship zsh git)

    for dep in "${deps[@]}"; do
        if ! command -v "$dep" &>/dev/null; then
            missing+=("$dep")
            warn "$dep not found"
        else
            success "$dep found"
        fi
    done

    if [ ${#missing[@]} -gt 0 ]; then
        echo ""
        warn "Missing packages: ${missing[*]}"
        warn "Install with: yay -S ${missing[*]}"
    fi
}

install_fonts() {
    info "Checking Nerd Fonts..."
    if fc-list | grep -qi "JetBrainsMono"; then
        success "JetBrainsMono Nerd Font already installed"
    else
        warn "JetBrainsMono Nerd Font not found"
        info "Install with: yay -S ttf-jetbrains-mono-nerd"
    fi
}

# ============ MAIN ============
print_header

echo -e "${BOLD}This will install dotfiles to ~/.config${NC}"
echo -n "Continue? [y/N] "
read -r response
if [[ ! "$response" =~ ^[Yy]$ ]]; then
    info "Aborted."
    exit 0
fi

backup_existing
link_dotfiles
check_deps
install_fonts

echo ""
echo -e "${BOLD}${GREEN}✓ Dotfiles installed successfully!${NC}"
echo ""
echo -e "${CYAN}Next steps:${NC}"
echo "  1. Install missing dependencies if any were listed above"
echo "  2. Log out and log back into Hyprland"
echo "  3. Set your wallpaper: cp your-wallpaper.jpg ~/Pictures/wallpaper.jpg"
echo "  4. Customize ~/.config/hypr/hyprland.conf to match your monitor setup"
echo ""
echo -e "${CYAN}Keybindings:${NC}"
echo "  Super + Return   → Terminal (kitty)"
echo "  Super + R        → App launcher (wofi)"
echo "  Super + Q        → Close window"
echo "  Super + F        → Fullscreen"
echo "  Super + V        → Toggle float"
echo "  Super + [1-0]    → Switch workspace"
echo "  Super + H/J/K/L  → Move focus (vim keys)"
echo "  Print            → Screenshot (to clipboard)"
echo ""
