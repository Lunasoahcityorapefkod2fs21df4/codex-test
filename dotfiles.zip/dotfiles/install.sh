#!/usr/bin/env bash
# ============================================
# Hyprland Dotfiles Installer
# For Arch Linux — VMware compatible
# ============================================

set -e

DOTFILES_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG="$HOME/.config"
BACKUP="$HOME/.config-backup-$(date +%Y%m%d-%H%M%S)"

# Colors
RED='\033[0;31m'
GRN='\033[0;32m'
YLW='\033[1;33m'
BLU='\033[0;34m'
CYN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

info()    { echo -e "${BLU}[INFO]${NC}  $1"; }
ok()      { echo -e "${GRN}[ OK ]${NC}  $1"; }
warn()    { echo -e "${YLW}[WARN]${NC}  $1"; }
err()     { echo -e "${RED}[ERR ]${NC}  $1"; }
step()    { echo -e "\n${BOLD}${CYN}==> $1${NC}"; }

# ============================================
# STEP 1 — Install yay if missing
# ============================================
install_yay() {
    if command -v yay &>/dev/null; then
        ok "yay already installed"
        return
    fi
    step "Installing yay (AUR helper)"
    sudo pacman -S --needed --noconfirm git base-devel
    git clone https://aur.archlinux.org/yay.git /tmp/yay-install
    cd /tmp/yay-install
    makepkg -si --noconfirm
    cd "$DOTFILES_DIR"
    ok "yay installed"
}

# ============================================
# STEP 2 — Install all packages
# ============================================
install_packages() {
    step "Installing pacman packages"
    sudo pacman -S --needed --noconfirm \
        waybar hyprpaper dunst kitty wofi \
        pipewire pipewire-pulse wireplumber pavucontrol \
        grim slurp wl-clipboard \
        zsh starship fzf fd \
        eza bat btop zoxide \
        playerctl brightnessctl \
        ttf-jetbrains-mono-nerd papirus-icon-theme noto-fonts \
        polkit-kde-agent \
        thunar \
        xdg-user-dirs \
        git curl wget unzip

    ok "pacman packages installed"

    step "Installing AUR packages"
    yay -S --needed --noconfirm \
        oh-my-zsh-git \
        zsh-autosuggestions \
        zsh-syntax-highlighting \
        zsh-completions \
        cliphist \
        bibata-cursor-theme-bin \
        catppuccin-gtk-theme-mocha

    ok "AUR packages installed"
}

# ============================================
# STEP 3 — Backup existing configs
# ============================================
backup_configs() {
    step "Backing up existing configs"
    mkdir -p "$BACKUP"
    for dir in hypr waybar wofi kitty dunst gtk-3.0 gtk-4.0; do
        if [ -d "$CONFIG/$dir" ]; then
            cp -r "$CONFIG/$dir" "$BACKUP/"
            ok "Backed up $dir"
        fi
    done
    [ -f "$HOME/.zshrc" ] && cp "$HOME/.zshrc" "$BACKUP/.zshrc" && ok "Backed up .zshrc"
    info "Backup saved to $BACKUP"
}

# ============================================
# STEP 4 — Copy dotfiles
# ============================================
install_dotfiles() {
    step "Installing dotfiles"

    mkdir -p "$CONFIG"

    # Remove old configs first
    rm -rf "$CONFIG/hypr"
    rm -rf "$CONFIG/waybar"
    rm -rf "$CONFIG/wofi"
    rm -rf "$CONFIG/kitty"
    rm -rf "$CONFIG/dunst"
    rm -rf "$CONFIG/gtk-3.0"
    rm -rf "$CONFIG/gtk-4.0"

    # Copy fresh
    cp -r "$DOTFILES_DIR/hypr"     "$CONFIG/hypr"      && ok "hypr"
    cp -r "$DOTFILES_DIR/waybar"   "$CONFIG/waybar"    && ok "waybar"
    cp -r "$DOTFILES_DIR/wofi"     "$CONFIG/wofi"      && ok "wofi"
    cp -r "$DOTFILES_DIR/kitty"    "$CONFIG/kitty"     && ok "kitty"
    cp -r "$DOTFILES_DIR/dunst"    "$CONFIG/dunst"     && ok "dunst"
    cp -r "$DOTFILES_DIR/gtk-3.0"  "$CONFIG/gtk-3.0"  && ok "gtk-3.0"
    cp -r "$DOTFILES_DIR/gtk-4.0"  "$CONFIG/gtk-4.0"  && ok "gtk-4.0"

    # Zsh
    cp "$DOTFILES_DIR/zsh/.zshrc" "$HOME/.zshrc" && ok ".zshrc"

    # Starship
    cp "$DOTFILES_DIR/zsh/starship.toml" "$CONFIG/starship.toml" && ok "starship.toml"

    ok "All dotfiles installed"
}

# ============================================
# STEP 5 — Set up Oh My Zsh plugins
# ============================================
setup_zsh_plugins() {
    step "Setting up Zsh plugins"

    ZSH_CUSTOM="${ZSH_CUSTOM:-$HOME/.oh-my-zsh/custom}"

    if [ ! -d "$ZSH_CUSTOM/plugins/zsh-autosuggestions" ]; then
        git clone https://github.com/zsh-users/zsh-autosuggestions \
            "$ZSH_CUSTOM/plugins/zsh-autosuggestions"
        ok "zsh-autosuggestions"
    else
        ok "zsh-autosuggestions already present"
    fi

    if [ ! -d "$ZSH_CUSTOM/plugins/zsh-syntax-highlighting" ]; then
        git clone https://github.com/zsh-users/zsh-syntax-highlighting \
            "$ZSH_CUSTOM/plugins/zsh-syntax-highlighting"
        ok "zsh-syntax-highlighting"
    else
        ok "zsh-syntax-highlighting already present"
    fi

    if [ ! -d "$ZSH_CUSTOM/plugins/zsh-completions" ]; then
        git clone https://github.com/zsh-users/zsh-completions \
            "$ZSH_CUSTOM/plugins/zsh-completions"
        ok "zsh-completions"
    else
        ok "zsh-completions already present"
    fi
}

# ============================================
# STEP 6 — Set zsh as default shell
# ============================================
set_default_shell() {
    step "Setting zsh as default shell"
    if [ "$SHELL" = "$(which zsh)" ]; then
        ok "zsh is already the default shell"
    else
        chsh -s "$(which zsh)"
        ok "Default shell set to zsh (takes effect on next login)"
    fi
}

# ============================================
# STEP 7 — Create required directories
# ============================================
create_dirs() {
    step "Creating required directories"
    mkdir -p \
        ~/Pictures/Screenshots \
        ~/.local/bin \
        ~/.local/share/zsh \
        ~/.cache/zsh
    xdg-user-dirs-update 2>/dev/null || true
    ok "Directories created"
}

# ============================================
# STEP 8 — Enable pipewire services
# ============================================
enable_services() {
    step "Enabling audio services"
    systemctl --user enable --now pipewire.service       2>/dev/null && ok "pipewire"       || warn "pipewire may already be enabled"
    systemctl --user enable --now pipewire-pulse.service 2>/dev/null && ok "pipewire-pulse" || warn "pipewire-pulse may already be enabled"
    systemctl --user enable --now wireplumber.service    2>/dev/null && ok "wireplumber"    || warn "wireplumber may already be enabled"
}

# ============================================
# MAIN
# ============================================
echo -e "\n${BOLD}${CYN}"
echo "  ██╗  ██╗██╗   ██╗██████╗ ██████╗ "
echo "  ██║  ██║╚██╗ ██╔╝██╔══██╗██╔══██╗"
echo "  ███████║ ╚████╔╝ ██████╔╝██████╔╝"
echo "  ██╔══██║  ╚██╔╝  ██╔═══╝ ██╔══██╗"
echo "  ██║  ██║   ██║   ██║     ██║  ██║"
echo "  ╚═╝  ╚═╝   ╚═╝   ╚═╝     ╚═╝  ╚═╝"
echo -e "  ${NC}${BOLD}Dotfiles Installer — Arch Linux / VMware${NC}\n"

echo -e "${BOLD}This will:${NC}"
echo "  • Install all required packages via pacman + yay"
echo "  • Backup your existing ~/.config entries"
echo "  • Copy all dotfiles to ~/.config"
echo "  • Set zsh as your default shell"
echo "  • Set up Oh My Zsh plugins"
echo ""
echo -n "Continue? [y/N] "
read -r response
[[ ! "$response" =~ ^[Yy]$ ]] && { info "Aborted."; exit 0; }

install_yay
install_packages
backup_configs
install_dotfiles
setup_zsh_plugins
set_default_shell
create_dirs
enable_services

echo ""
echo -e "${BOLD}${GRN}✓ Done! Everything is installed.${NC}"
echo ""
echo -e "${CYN}Next steps:${NC}"
echo "  1. Add a wallpaper:  cp your-image.jpg ~/Pictures/wallpaper.jpg"
echo "  2. Log out of SDDM and log back in"
echo "  3. Hyprland should now load your config automatically"
echo ""
echo -e "${CYN}If Hyprland still shows the example config:${NC}"
echo "  Run:  cp -r ~/.config/hypr ~/.config/hypr.bak && hyprctl reload"
echo ""
echo -e "${CYN}Key bindings:${NC}"
echo "  Super + Return  → Terminal"
echo "  Super + R       → App launcher"
echo "  Super + Q       → Close window"
echo "  Super + H/J/K/L → Move focus"
echo "  Super + 1-0     → Switch workspace"
echo ""
