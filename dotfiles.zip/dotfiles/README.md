# Hyprland Dotfiles 🌸

A clean, minimal **Hyprland** setup using the **Catppuccin Mocha** color scheme.

## 📸 Preview

- **WM:** Hyprland (Wayland)
- **Bar:** Waybar
- **Terminal:** Kitty
- **Shell:** Zsh + Oh My Zsh + Starship
- **Launcher:** Wofi
- **Notifications:** Dunst
- **Theme:** Catppuccin Mocha
- **Font:** JetBrainsMono Nerd Font

## 📁 Structure

```
dotfiles/
├── hypr/
│   ├── hyprland.conf      # Main Hyprland config
│   └── hyprpaper.conf     # Wallpaper config
├── waybar/
│   ├── config.jsonc       # Waybar layout
│   └── style.css          # Waybar styling
├── kitty/
│   └── kitty.conf         # Kitty terminal config
├── wofi/
│   ├── config             # Wofi settings
│   └── style.css          # Wofi styling
├── dunst/
│   └── dunstrc            # Notification daemon config
├── gtk-3.0/
│   └── settings.ini       # GTK3 theme settings
├── zsh/
│   ├── .zshrc             # Zsh config
│   └── starship.toml      # Starship prompt config
├── install.sh             # Auto-install script
└── README.md
```

## 🚀 Installation

### Quick Install

```bash
git clone https://github.com/yourusername/dotfiles ~/Dotfiles
cd ~/Dotfiles
chmod +x install.sh
./install.sh
```

### Manual Install

```bash
cp -r hypr     ~/.config/hypr
cp -r waybar   ~/.config/waybar
cp -r kitty    ~/.config/kitty
cp -r wofi     ~/.config/wofi
cp -r dunst    ~/.config/dunst
cp -r gtk-3.0  ~/.config/gtk-3.0
cp zsh/.zshrc  ~/.zshrc
cp zsh/starship.toml ~/.config/starship.toml
```

## 📦 Dependencies

### Required

| Package | Purpose |
|--------|---------|
| `hyprland` | Window manager |
| `waybar` | Status bar |
| `kitty` | Terminal emulator |
| `wofi` | App launcher |
| `dunst` | Notifications |
| `hyprpaper` | Wallpaper daemon |
| `zsh` | Shell |
| `starship` | Shell prompt |
| `oh-my-zsh` | Zsh framework |

### Recommended

| Package | Purpose |
|--------|---------|
| `eza` | Better `ls` |
| `bat` | Better `cat` |
| `fzf` | Fuzzy finder |
| `fd` | Better `find` |
| `btop` | System monitor |
| `zoxide` | Smarter `cd` |
| `grim` | Screenshot tool |
| `slurp` | Screen region select |
| `wl-copy` | Clipboard |
| `cliphist` | Clipboard manager |
| `pavucontrol` | Audio control |
| `playerctl` | Media control |
| `brightnessctl` | Brightness control |
| `wlogout` | Logout menu |
| `ttf-jetbrains-mono-nerd` | Nerd font |
| `papirus-icon-theme` | Icon theme |
| `bibata-cursor-theme` | Cursor theme |

### Install all at once (Arch/yay)

```bash
yay -S hyprland waybar kitty wofi dunst hyprpaper zsh starship \
       eza bat fzf fd btop zoxide grim slurp wl-clipboard cliphist \
       pavucontrol playerctl brightnessctl wlogout \
       ttf-jetbrains-mono-nerd papirus-icon-theme bibata-cursor-theme-bin \
       catppuccin-gtk-theme-mocha
```

## ⌨️ Keybindings

| Keys | Action |
|------|--------|
| `Super + Return` | Open terminal |
| `Super + R` | App launcher |
| `Super + Q` | Close window |
| `Super + F` | Fullscreen |
| `Super + V` | Toggle float |
| `Super + S` | Scratchpad |
| `Super + E` | File manager |
| `Super + H/J/K/L` | Move focus |
| `Super + Shift + H/J/K/L` | Move window |
| `Super + Alt + H/J/K/L` | Resize window |
| `Super + [1-0]` | Switch workspace |
| `Super + Shift + [1-0]` | Move to workspace |
| `Print` | Screenshot to clipboard |
| `Shift + Print` | Screenshot to file |
| `Super + .` | Clipboard history |
| `Super + Shift + E` | Exit Hyprland |

## 🎨 Customization

### Change wallpaper

```bash
cp ~/Pictures/your-wallpaper.jpg ~/Pictures/wallpaper.jpg
hyprctl hyprpaper reload
```

### Change monitor layout

Edit `~/.config/hypr/hyprland.conf`:

```ini
monitor=DP-1,1920x1080@144,0x0,1
monitor=HDMI-A-1,1920x1080@60,1920x0,1
```

### Change color scheme

Colors are defined as CSS variables in `waybar/style.css` and can be adjusted there. Kitty colors are in `kitty/kitty.conf`.

## 📄 License

MIT — feel free to fork and customize!
