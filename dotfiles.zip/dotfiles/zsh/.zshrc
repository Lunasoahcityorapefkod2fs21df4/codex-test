# ========================
# ~/.zshrc
# ========================

# ========================
# OH MY ZSH (if installed)
# ========================
if [ -f "$HOME/.oh-my-zsh/oh-my-zsh.sh" ]; then
    export ZSH="$HOME/.oh-my-zsh"
    ZSH_THEME=""

    # Only load plugins that are actually installed
    plugins=(git)

    [ -d "$ZSH/custom/plugins/zsh-autosuggestions" ]   && plugins+=(zsh-autosuggestions)
    [ -d "$ZSH/custom/plugins/zsh-syntax-highlighting" ] && plugins+=(zsh-syntax-highlighting)
    [ -d "$ZSH/custom/plugins/zsh-completions" ]        && plugins+=(zsh-completions)

    plugins+=(sudo colored-man-pages extract z)

    source "$ZSH/oh-my-zsh.sh"
fi

# ========================
# ENVIRONMENT VARIABLES
# ========================
export EDITOR="nvim"
export VISUAL="nvim"
export BROWSER="firefox"
export LANG="en_US.UTF-8"
export LC_ALL="en_US.UTF-8"
export XDG_CONFIG_HOME="$HOME/.config"
export XDG_DATA_HOME="$HOME/.local/share"
export XDG_CACHE_HOME="$HOME/.cache"
export PATH="$HOME/.local/bin:$PATH"

# ========================
# COMPLETION
# ========================
autoload -Uz compinit
compinit -d "${XDG_CACHE_HOME:-$HOME/.cache}/zsh/zcompdump"

zstyle ':completion:*' menu select
zstyle ':completion:*' matcher-list 'm:{a-zA-Z}={A-Za-z}'
zstyle ':completion:*' list-colors "${(s.:.)LS_COLORS}"
zstyle ':completion:*' group-name ''

# ========================
# HISTORY
# ========================
HISTSIZE=50000
SAVEHIST=50000
HISTFILE="${XDG_DATA_HOME:-$HOME/.local/share}/zsh/history"
mkdir -p "$(dirname "$HISTFILE")"
setopt HIST_IGNORE_DUPS HIST_IGNORE_ALL_DUPS SHARE_HISTORY APPEND_HISTORY

# ========================
# OPTIONS
# ========================
setopt AUTO_CD
setopt AUTO_PUSHD
setopt PUSHD_IGNORE_DUPS
setopt INTERACTIVE_COMMENTS
setopt NO_BEEP

# ========================
# KEYBINDINGS
# ========================
bindkey -e
bindkey '^[[1;5C' forward-word
bindkey '^[[1;5D' backward-word

# ========================
# ALIASES — Navigation
# ========================
alias ..='cd ..'
alias ...='cd ../..'
alias ....='cd ../../..'

# ========================
# ALIASES — ls
# ========================
if command -v eza &>/dev/null; then
    alias ls='eza --icons --group-directories-first'
    alias la='eza --icons --group-directories-first -a'
    alias ll='eza --icons --group-directories-first -l'
    alias lla='eza --icons --group-directories-first -la'
    alias lt='eza --icons --tree --level=2'
else
    alias ls='ls --color=auto'
    alias la='ls -A'
    alias ll='ls -lh'
    alias lla='ls -lAh'
fi

# ========================
# ALIASES — cat / grep
# ========================
command -v bat &>/dev/null && alias cat='bat --style=plain'
alias grep='grep --color=auto'

# ========================
# ALIASES — editors
# ========================
command -v nvim &>/dev/null && alias vi='nvim' && alias vim='nvim' && alias v='nvim'

# ========================
# ALIASES — top
# ========================
command -v btop &>/dev/null && alias top='btop'

# ========================
# ALIASES — Git
# ========================
alias g='git'
alias ga='git add'
alias gaa='git add --all'
alias gc='git commit -m'
alias gco='git checkout'
alias gcb='git checkout -b'
alias gd='git diff'
alias gf='git fetch'
alias gl='git log --oneline --graph --decorate'
alias gp='git push'
alias gpl='git pull'
alias gs='git status -sb'

# ========================
# ALIASES — Pacman / Yay
# ========================
alias pac='sudo pacman'
alias pacs='sudo pacman -S'
alias pacr='sudo pacman -Rns'
alias pacu='sudo pacman -Syu'
alias ys='yay -S'
alias yr='yay -Rns'
alias yu='yay -Syu'

# ========================
# ALIASES — Misc
# ========================
alias cp='cp -iv'
alias mv='mv -iv'
alias rm='rm -Iv'
alias mkdir='mkdir -pv'
alias df='df -h'
alias du='du -sh'
alias clr='clear'
alias q='exit'
alias reload='source ~/.zshrc'
alias zshrc='${EDITOR:-nano} ~/.zshrc'
alias hyprconf='${EDITOR:-nano} ~/.config/hypr/hyprland.conf'
alias wayconf='${EDITOR:-nano} ~/.config/waybar/config.jsonc'
alias dots='cd ~/Dotfiles'

# ========================
# FUNCTIONS
# ========================
mkcd() { mkdir -p "$@" && cd "$_"; }

extract() {
    if [ -f "$1" ]; then
        case "$1" in
            *.tar.bz2) tar xjf "$1" ;;
            *.tar.gz)  tar xzf "$1" ;;
            *.bz2)     bunzip2 "$1" ;;
            *.gz)      gunzip "$1"  ;;
            *.tar)     tar xf "$1"  ;;
            *.zip)     unzip "$1"   ;;
            *.7z)      7z x "$1"    ;;
            *)         echo "'$1' cannot be extracted" ;;
        esac
    else
        echo "'$1' is not a valid file"
    fi
}

# ========================
# FZF
# ========================
[ -f /usr/share/fzf/key-bindings.zsh ]  && source /usr/share/fzf/key-bindings.zsh
[ -f /usr/share/fzf/completion.zsh ]    && source /usr/share/fzf/completion.zsh

export FZF_DEFAULT_OPTS="
    --color=bg+:#313244,bg:#1e1e2e,spinner:#f5e0dc,hl:#f38ba8
    --color=fg:#cdd6f4,header:#f38ba8,info:#cba6f7,pointer:#f5e0dc
    --color=marker:#f5e0dc,fg+:#cdd6f4,prompt:#cba6f7,hl+:#f38ba8
    --height 40% --layout=reverse --border=rounded
"

# ========================
# ZOXIDE (smarter cd)
# ========================
command -v zoxide &>/dev/null && eval "$(zoxide init zsh)"

# ========================
# STARSHIP PROMPT
# ========================
command -v starship &>/dev/null && eval "$(starship init zsh)"
