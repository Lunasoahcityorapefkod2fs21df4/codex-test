# ========================
# ~/.zshrc — Main ZSH Config
# ========================

# Path to oh-my-zsh installation
export ZSH="$HOME/.oh-my-zsh"

# Theme (using starship for prompt instead)
ZSH_THEME=""

# Plugins
plugins=(
    git
    zsh-autosuggestions
    zsh-syntax-highlighting
    zsh-completions
    fzf
    sudo
    colored-man-pages
    extract
    z
)

source $ZSH/oh-my-zsh.sh

# ========================
# ENVIRONMENT VARIABLES
# ========================
export EDITOR="nvim"
export VISUAL="nvim"
export BROWSER="firefox"
export TERM="xterm-256color"
export LANG="en_US.UTF-8"
export LC_ALL="en_US.UTF-8"
export XDG_CONFIG_HOME="$HOME/.config"
export XDG_DATA_HOME="$HOME/.local/share"
export XDG_CACHE_HOME="$HOME/.cache"

# Path additions
export PATH="$HOME/.local/bin:$HOME/scripts:$PATH"

# ========================
# ALIASES — Navigation
# ========================
alias ..='cd ..'
alias ...='cd ../..'
alias ....='cd ../../..'
alias ~='cd ~'
alias -- -='cd -'

# ========================
# ALIASES — ls (using eza)
# ========================
alias ls='eza --icons --group-directories-first'
alias la='eza --icons --group-directories-first -a'
alias ll='eza --icons --group-directories-first -l'
alias lla='eza --icons --group-directories-first -la'
alias lt='eza --icons --tree --level=2'
alias lta='eza --icons --tree --level=2 -a'

# ========================
# ALIASES — Git
# ========================
alias g='git'
alias ga='git add'
alias gaa='git add --all'
alias gc='git commit -m'
alias gca='git commit --amend'
alias gco='git checkout'
alias gcb='git checkout -b'
alias gd='git diff'
alias gds='git diff --staged'
alias gf='git fetch'
alias gl='git log --oneline --graph --decorate'
alias gp='git push'
alias gpf='git push --force-with-lease'
alias gpl='git pull'
alias gs='git status -sb'
alias gst='git stash'
alias gstp='git stash pop'

# ========================
# ALIASES — System
# ========================
alias cat='bat --style=plain'
alias grep='grep --color=auto'
alias cp='cp -iv'
alias mv='mv -iv'
alias rm='rm -Iv'
alias mkdir='mkdir -pv'
alias df='df -h'
alias du='du -sh'
alias free='free -mh'
alias ps='ps auxf'
alias top='btop'
alias vi='nvim'
alias vim='nvim'
alias v='nvim'
alias p='python3'
alias py='python3'

# ========================
# ALIASES — Pacman / Yay
# ========================
alias pac='sudo pacman'
alias pacs='sudo pacman -S'
alias pacr='sudo pacman -Rns'
alias pacu='sudo pacman -Syu'
alias pacq='pacman -Q'
alias yay='yay --noconfirm'
alias ys='yay -S'
alias yr='yay -Rns'
alias yu='yay -Syu'

# ========================
# ALIASES — Misc
# ========================
alias reload='source ~/.zshrc'
alias zshrc='nvim ~/.zshrc'
alias hyprconf='nvim ~/.config/hypr/hyprland.conf'
alias wayconf='nvim ~/.config/waybar/config.jsonc'
alias kittyconf='nvim ~/.config/kitty/kitty.conf'
alias dots='cd ~/Dotfiles'
alias notes='cd ~/Notes'
alias clr='clear'
alias q='exit'

# ========================
# FUNCTIONS
# ========================

# Create directory and cd into it
mkcd() {
    mkdir -p "$@" && cd "$_"
}

# Extract any archive
extract() {
    if [ -f "$1" ]; then
        case "$1" in
            *.tar.bz2)   tar xjf "$1"   ;;
            *.tar.gz)    tar xzf "$1"   ;;
            *.bz2)       bunzip2 "$1"   ;;
            *.rar)       unrar x "$1"   ;;
            *.gz)        gunzip "$1"    ;;
            *.tar)       tar xf "$1"    ;;
            *.tbz2)      tar xjf "$1"   ;;
            *.tgz)       tar xzf "$1"   ;;
            *.zip)       unzip "$1"     ;;
            *.Z)         uncompress "$1";;
            *.7z)        7z x "$1"      ;;
            *)           echo "'$1' cannot be extracted" ;;
        esac
    else
        echo "'$1' is not a valid file"
    fi
}

# Quick backup of a file
bak() {
    cp "$1"{,.bak}
}

# Show PATH entries one per line
path() {
    echo "$PATH" | tr ':' '\n'
}

# Open file manager in current directory
open() {
    xdg-open "$@" &>/dev/null &
}

# Git clone and cd
gclone() {
    git clone "$1" && cd "$(basename "$1" .git)"
}

# ========================
# COMPLETION
# ========================
autoload -Uz compinit
compinit -d "$XDG_CACHE_HOME/zsh/zcompdump-$ZSH_VERSION"

zstyle ':completion:*' menu select
zstyle ':completion:*' matcher-list 'm:{a-zA-Z}={A-Za-z}'
zstyle ':completion:*' list-colors "${(s.:.)LS_COLORS}"
zstyle ':completion:*:descriptions' format '%F{yellow}-- %d --%f'
zstyle ':completion:*' group-name ''

# ========================
# HISTORY
# ========================
HISTSIZE=50000
SAVEHIST=50000
HISTFILE="$XDG_DATA_HOME/zsh/history"
setopt HIST_EXPIRE_DUPS_FIRST
setopt HIST_IGNORE_DUPS
setopt HIST_IGNORE_ALL_DUPS
setopt HIST_FIND_NO_DUPS
setopt HIST_SAVE_NO_DUPS
setopt SHARE_HISTORY
setopt APPEND_HISTORY

# ========================
# OPTIONS
# ========================
setopt AUTO_CD
setopt AUTO_PUSHD
setopt PUSHD_IGNORE_DUPS
setopt PUSHD_SILENT
setopt CORRECT
setopt CORRECT_ALL
setopt INTERACTIVE_COMMENTS
setopt NO_BEEP

# ========================
# KEYBINDINGS
# ========================
bindkey -e
bindkey '^[[A' history-substring-search-up
bindkey '^[[B' history-substring-search-down
bindkey '^[[1;5C' forward-word
bindkey '^[[1;5D' backward-word
bindkey '^H' backward-kill-word
bindkey '^[[3;5~' kill-word

# ========================
# FZF
# ========================
[ -f ~/.fzf.zsh ] && source ~/.fzf.zsh

export FZF_DEFAULT_COMMAND='fd --type f --hidden --follow --exclude .git'
export FZF_DEFAULT_OPTS="
    --color=bg+:#313244,bg:#1e1e2e,spinner:#f5e0dc,hl:#f38ba8
    --color=fg:#cdd6f4,header:#f38ba8,info:#cba6f7,pointer:#f5e0dc
    --color=marker:#f5e0dc,fg+:#cdd6f4,prompt:#cba6f7,hl+:#f38ba8
    --height 40% --layout=reverse --border=rounded
    --preview 'bat --style=numbers --color=always --line-range :500 {}'
"
export FZF_CTRL_T_COMMAND="$FZF_DEFAULT_COMMAND"
export FZF_ALT_C_COMMAND='fd --type d --hidden --follow --exclude .git'

# ========================
# STARSHIP PROMPT
# ========================
eval "$(starship init zsh)"

# ========================
# ZOXIDE (smarter cd)
# ========================
eval "$(zoxide init zsh)"
